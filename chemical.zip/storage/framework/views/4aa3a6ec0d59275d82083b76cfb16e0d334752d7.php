<?php $__env->startSection('content'); ?>
<div id="main-content">
    <div class="container-fluid">
        <!-- Page header section  -->
        <div class="block-header">
            <div class="row clearfix">
                <div class="col-lg-4 col-md-12 col-sm-12">
                    <h1>Dashboard</h1>
                    <span>Selamat Datang di Inventory Control</span>
                </div>
                <div class="col-lg-8 col-md-12 col-sm-12 text-lg-right">

                </div>
            </div>
        </div>
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12">
                <div class="card planned_task">
                    <div class="header">
                        <h2 class="text-center">LAPORAN CHEMICAL</h2>
                        <ul class="header-dropdown dropdown">
                            <li><a href="javascript:void(0);" class="full-screen"><i class="fa fa-expand"></i></a></li>
                        </ul>
                        <button class="btn btn-primary theme-bg gradient" data-toggle="modal" data-target="#mainForm">
                            TAMBAH DATA LAPORAN
                        </button>
                        <a href="<?php echo e(route('laporan_export')); ?>" class="btn btn-primary theme-bg gradient pull-right" title="Download to Excel">
                            <i class="fa fa-lg fa-cloud-download"></i>
                        </a>
                    </div>
                    <div class="body">
                        <div class="table-responsive">
                            <table class="table js-basic-example dataTable table-custom spacing5 table-bordered" id="chemical">
                                <thead>
                                    <tr>
                                        <th>Unit</th>
                                        <th>kimap</th>
                                        <th>Desc.</th>
                                        <th>Satuan</th>
                                        <th>Konsumsi</th>
                                        <th>SOH</th>
                                        <th>OS PR</th>
                                        <th>OS PO</th>
                                        <th>Ketahanan Stock</th>
                                        <th>Lead Time(Bulan)</th>
                                        <th>Indikator</th>
                                        <th>Ket.</th>
                                        <th>Warning</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(strtoupper($i->barang->nm_barang)); ?></td>
                                        <td><?php echo e(strtoupper($i->barang->kimap)); ?></td>
                                        <td><?php echo e(strtoupper($i->desc)); ?></td>
                                        <td><?php echo e(strtoupper($i->barang->satuan->name)); ?></td>
                                        <td><?php echo e(strtoupper($i->konsumsi)); ?></td>
                                        <td><?php echo e(strtoupper($i->soh)); ?></td>
                                        <td><?php echo e(strtoupper($i->ospr)); ?></td>
                                        <td><?php echo e(strtoupper($i->ospo)); ?></td>
                                        <td><?php echo e(strtoupper($i->ketahanan_stock)); ?></td>
                                        <td><?php echo e(strtoupper($i->lead_time )); ?></td>
                                        <td><?php echo e(strtoupper($i->indikator)); ?></td>
                                        <td><?php echo e(strtoupper($i->ket)); ?></td>
                                        <td>
                                            <?php if($i->ketahanan_stock < 30): ?>
                                            <span class="badge badge-danger sub_n_category bg-red">Stock kurang 30</span>
                                            <?php elseif($i->ketahanan_stock < 50): ?>
                                            <span class="badge badge-warning sub_n_category bg-orange">Stock mendekati 30</span>
                                            <?php else: ?>
                                            <span class="badge badge-success sub_n_category bg-green">Stock Aman</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <button class="btn btn-success gradient" title="Edit Data">
                                                <i class="fa fa-pencil"></i>
                                            </button>
                                            <button class="btn btn-warning gradient" title="Hapus Data">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('main-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\chemical\resources\views/home.blade.php ENDPATH**/ ?>